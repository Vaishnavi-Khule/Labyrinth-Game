import grpc
from concurrent import futures
import labyrinth_pb2
import labyrinth_pb2_grpc
import random

class LabyrinthGameServicer(labyrinth_pb2_grpc.LabyrinthGameServicer):
    def __init__(self):
        self.health = 3
        self.coins_collected = 0
        self.spells_used = 0
        self.spell_limit = 3
        self.grid = []
        self.player_position = (0, 0)
        self.game_over = False

    def start_labyrinth(self, m, n):
        self.grid = [[random.choice([labyrinth_pb2.Tile.TileType.EMPTY,
                                     labyrinth_pb2.Tile.TileType.COIN,
                                     labyrinth_pb2.Tile.TileType.WALL]) for _ in range(n)] for _ in range(m)]
        self.grid[0][0] = labyrinth_pb2.Tile.TileType.EMPTY
        self.grid[m-1][n-1] = labyrinth_pb2.Tile.TileType.EMPTY
        self.player_position = (0, 0)

    def StartGame(self, request, context):
        self.start_labyrinth(5, 5)  # Default 5x5 grid
        response = labyrinth_pb2.StartResponse(m=5, n=5)
        for row in self.grid:
            for tile in row:
                response.grid.append(labyrinth_pb2.Tile(type=tile))
        return response

    def MovePlayer(self, request, context):
        if self.game_over:
            return labyrinth_pb2.MoveResponse(result="Game over", gameOver=True)

        x, y = self.player_position
        # target_row, target_col = response.m - 1, response.n - 1
        if request.direction == labyrinth_pb2.MoveRequest.UP and x > 0:
            new_x = x - 1
            new_y = y
        elif request.direction == labyrinth_pb2.MoveRequest.DOWN and x < len(self.grid) - 1:
            new_x = x + 1
            new_y = y
        elif request.direction == labyrinth_pb2.MoveRequest.LEFT and y > 0:
            new_x = x
            new_y = y - 1
        elif request.direction == labyrinth_pb2.MoveRequest.RIGHT and y < len(self.grid[0]) - 1:
            new_x = x
            new_y = y + 1
        else:
            return labyrinth_pb2.MoveResponse(result="Invalid move", gameOver=False)

        tile = self.grid[new_x][new_y]

        # Process the move based on the tile type
        if tile == labyrinth_pb2.Tile.TileType.EMPTY:
            result = "Moved to an empty tile"
            self.player_position = (new_x, new_y)  # Update player position
        elif tile == labyrinth_pb2.Tile.TileType.COIN:
            result = "Collected a coin"
            self.coins_collected += 1
            self.grid[new_x][new_y] = labyrinth_pb2.Tile.TileType.EMPTY  # Remove the coin
            self.player_position = (new_x, new_y)  # Update player position
        elif tile == labyrinth_pb2.Tile.TileType.WALL:
            result = "Hit a wall. You cannot move through walls."  # Inform the player of the wal
            self.health -= 1
            if self.health == 0:
                self.game_over = True
                result = "You ran out of lives. Game Over!"

        if self.player_position == (len(self.grid) - 1, len(self.grid[0]) - 1):
            self.game_over = True
            result = "Congratulations"

        return labyrinth_pb2.MoveResponse(
            result=result,
            coinsCollected=self.coins_collected,
            health=self.health,
            gameOver=self.game_over
        )

    def CastSpell(self, request, context):
        if self.spells_used > self.spell_limit:
            return labyrinth_pb2.SpellResponse(result="No spells left", success=False)
        print(f"you used {self.spells_used} spells")
        if request.spell == labyrinth_pb2.SpellRequest.REVELIO:
            revealed_tiles = []
            for i in range(request.targetRow - 1, request.targetRow + 2):
                for j in range(request.targetCol - 1, request.targetCol + 2):
                    if 0 <= i < len(self.grid) and 0 <= j < len(self.grid[0]):
                        if self.grid[i][j] == request.revealType:
                            revealed_tiles.append((i, j))

            # Use the enum class to get the name of the reveal type
            revealed_type_name = labyrinth_pb2.Tile.TileType.Name(request.revealType)
            result = f"Revealed {len(revealed_tiles)} {revealed_type_name.lower()} tiles in the nearby area"
            self.spells_used += 1

            # Return the result of the spell
            return labyrinth_pb2.SpellResponse(result=result, success=True)

        # Handle other spells if needed
        elif request.spell == labyrinth_pb2.SpellRequest.BOMBARDA:
            destroyed_tiles = []

            for coord in request.targetTiles:  # Loop through each target tile
                row = coord.row
                col = coord.col
                if 0 <= row < len(self.grid) and 0 <= col < len(self.grid[0]):
                    # Destroy the object if it's a coin or a wall
                    self.grid[row][col] = labyrinth_pb2.Tile.TileType.EMPTY
                    result = f"Bombarda! Destroyed object at ({row}, {col})."
                    self.spells_used += 1
                    return labyrinth_pb2.SpellResponse(result=result, success=True)

            return labyrinth_pb2.SpellResponse(result="No objects were destroyed.", success=False)

        return labyrinth_pb2.SpellResponse(result="Unknown spell", success=False)

    # Add this method to the LabyrinthGameServicer class
    def GetCurrentPosition(self, request, context):
        x, y = self.player_position  # Access the current player position
        return labyrinth_pb2.PositionResponse(x=x, y=y)  # Send back the coordinates

    def GetLabyrinthInfo(self, request, context):
        # Return the width (m) and height (n) of the labyrinth
        return labyrinth_pb2.LabyrinthInfoResponse(width=len(self.grid), height=len(self.grid[0]))

    def GetPlayerStatus(self, request, context):
        x, y = self.player_position  # Get the player's current position
        remaining_spells = self.spell_limit - self.spells_used  # Calculate remaining spells
        return labyrinth_pb2.PlayerStatusResponse(
            score=self.coins_collected,
            health=self.health,
            position=labyrinth_pb2.Position(x=x, y=y),  # Use a Position message type
            remainingSpells=remaining_spells
        )


def serve():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    labyrinth_pb2_grpc.add_LabyrinthGameServicer_to_server(LabyrinthGameServicer(), server)
    server.add_insecure_port('[::]:50051')
    server.start()
    server.wait_for_termination()

if __name__ == '__main__':
    serve()

