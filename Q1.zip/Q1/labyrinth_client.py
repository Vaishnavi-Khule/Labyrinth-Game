import grpc
import labyrinth_pb2
import labyrinth_pb2_grpc

def run():
    with grpc.insecure_channel('localhost:50051') as channel:
        stub = labyrinth_pb2_grpc.LabyrinthGameStub(channel)

        # Start the game
        response = stub.StartGame(labyrinth_pb2.StartRequest())
        print("Labyrinth size:", response.m, "x", response.n)
        print("Grid:", [[tile.type for tile in response.grid[i * response.n:(i + 1) * response.n]] for i in range(response.m)])

        while True:
            move = input("Enter move (up, down, left, right) or spell (revelio/bombarda): ").lower()
            if move in ['u', 'd', 'l', 'r']:
                direction = {
                    'u': labyrinth_pb2.MoveRequest.UP,
                    'd': labyrinth_pb2.MoveRequest.DOWN,
                    'l': labyrinth_pb2.MoveRequest.LEFT,
                    'r': labyrinth_pb2.MoveRequest.RIGHT
                }[move]
                move_response = stub.MovePlayer(labyrinth_pb2.MoveRequest(direction=direction))
                print(move_response.result)
                if move_response.gameOver:
                    if "ran out of lives" in move_response.result:
                        print("You ran out of lives, Game Over!")
                    elif "Congratulations" in move_response.result:
                        print("Congratulations! You've reached the end of the labyrinth!")
                    break
            elif move == 're':
                row = int(input("Enter target row: "))
                col = int(input("Enter target col: "))
                reveal_type_input = input("Reveal coin or wall? ").lower()
                if reveal_type_input == "coin":
                    reveal_type = labyrinth_pb2.Tile.TileType.COIN
                elif reveal_type_input == "wall":
                    reveal_type = labyrinth_pb2.Tile.TileType.WALL
                else:
                    print("Invalid input, defaulting to coin.")
                    reveal_type = labyrinth_pb2.Tile.TileType.COIN
                spell_response = stub.CastSpell(labyrinth_pb2.SpellRequest(
                    spell=labyrinth_pb2.SpellRequest.REVELIO,
                    targetRow=row,
                    targetCol=col,
                    revealType=reveal_type
                ))
                print(spell_response.result)
            elif move == 'b':
                row = int(input("Enter target row for Bombarda: "))
                col = int(input("Enter target col for Bombarda: "))

                # Call the Bombarda spell with a single target tile
                spell_response = stub.CastSpell(labyrinth_pb2.SpellRequest(
                    spell=labyrinth_pb2.SpellRequest.BOMBARDA,
                    targetTiles=[labyrinth_pb2.Coordinate(row=row, col=col)]  # Send a single target tile
                ))
                print(spell_response.result)
            elif move == 'p':
                position_response = stub.GetCurrentPosition(labyrinth_pb2.EmptyRequest())
                print(f"Current position: ({position_response.x}, {position_response.y})")
            else:
                print("Invalid input")

if __name__ == '__main__':
    run()
